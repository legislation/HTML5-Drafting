require 'mercury/rails'

