module Mercury
  module Authentication

    def can_edit?
      true # check here to see if the user is logged in/has access
    end

  end
end
