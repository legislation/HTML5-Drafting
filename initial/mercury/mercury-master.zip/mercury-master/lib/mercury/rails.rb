module Mercury
  require 'coffee_script'
  require 'mercury/version'
  require 'mercury/engine'
end
