/*!
 * This is an example plugin that will serialize to XML instead of JSON before saving.  This could be useful to someone,
 * but is mostly provided as an example of how to write a simple plugin.
 *
 * This file is could be a nice place to provide configuration options for your plugin.
 *
 *= require_self
 *= require_tree ./mercury
 */
