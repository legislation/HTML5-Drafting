# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dummy::Application.config.secret_token = 'ec75f12ba523ebcf72816bb629915361a7cd7d75df9059ebf8a3cf4d74e0378f4a591e5366cd14b03a95e59fa7912a134bb3a69753458febd6c74a8ba0d23697'
